export interface Task {
  id: string;
  title: string;
  status: 'completed' | 'in-progress' | 'pending';
  description: string;
  hasExternalLink: boolean;
  priority: 'low' | 'medium' | 'high';
  assignedTo?: string;
  createdAt: Date;
  updatedAt: Date;
  tags: string[];
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  description: string;
  avatar: string;
  isActive: boolean;
  expertise: string[];
  lastActive?: Date;
}

export interface Message {
  id: string;
  agentId: string;
  content: string;
  timestamp: Date;
  type?: 'task' | 'suggestion' | 'question' | 'response';
}