import React, { useState, useCallback } from 'react';
import { Search, Plus, Filter, AlertCircle, Brain, Zap, SlidersHorizontal, LayoutGrid, List } from 'lucide-react';
import { Task, Agent, Message } from './types';
import { AgentCard } from './components/AgentCard';
import { AgentChat } from './components/AgentChat';
import { TaskCard } from './components/TaskCard';
import { generateResponse } from './lib/gemini';
import { parseTasksFromResponse } from './lib/taskParser';

function App() {
  const [expandedTasks, setExpandedTasks] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<Task['status'] | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<Task['priority'] | 'all'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [agents, setAgents] = useState<Agent[]>([
    {
      id: '1',
      name: 'Project Manager',
      role: 'Task Coordinator',
      description: 'Coordinates tasks and ensures project goals are met efficiently. Specializes in Agile methodologies and team organization.',
      avatar: '',
      isActive: false,
      expertise: ['Planning', 'Organization', 'Team Management', 'Risk Assessment', 'Agile Methodology']
    },
    {
      id: '2',
      name: 'Developer',
      role: 'Technical Implementation',
      description: 'Full-stack developer with expertise in modern web technologies. Handles technical implementation and architecture decisions.',
      avatar: '',
      isActive: false,
      expertise: ['Frontend', 'Backend', 'API Integration', 'Database Design', 'Testing', 'Performance']
    },
    {
      id: '3',
      name: 'Designer',
      role: 'UI/UX Design',
      description: 'Creates intuitive and beautiful user interfaces with a focus on user experience and accessibility standards.',
      avatar: '',
      isActive: false,
      expertise: ['UI Design', 'UX Research', 'Prototyping', 'User Testing', 'Visual Design', 'Accessibility']
    }
  ]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleAgentActivation = (agentId: string) => {
    setAgents(agents.map(agent => ({
      ...agent,
      isActive: agent.id === agentId ? !agent.isActive : agent.isActive,
      lastActive: agent.id === agentId ? new Date() : agent.lastActive
    })));
  };

  const addTasksFromResponse = (response: string, agentId: string) => {
    const parsedTasks = parseTasksFromResponse(response);
    if (parsedTasks.length > 0) {
      const newTasks = parsedTasks.map(task => ({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        title: task.title,
        description: task.description,
        status: task.status,
        hasExternalLink: false,
        priority: 'medium' as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        assignedTo: agents.find(a => a.id === agentId)?.name,
        tags: task.tags
      }));
      setTasks(prev => [...prev, ...newTasks]);
    }
  };

  const handleSendMessage = async (content: string) => {
    setIsProcessing(true);
    const newMessage: Message = {
      id: Date.now().toString(),
      agentId: 'user',
      content,
      timestamp: new Date(),
      type: 'question'
    };

    setMessages(prev => [...prev, newMessage]);

    const activeAgents = agents.filter(agent => agent.isActive);

    try {
      for (const agent of activeAgents) {
        const prompt = `You are a ${agent.role} named ${agent.name} with expertise in ${agent.expertise.join(', ')}. 
Your task is to respond to this message: "${content}"

Please provide your response in the following format for each task you identify:

Task: [Provide a clear, concise task name]
Description: [Provide a detailed description of what needs to be done]
Status: [Use one of: completed, in-progress, pending]

You can identify multiple tasks by repeating this format. Keep your response focused on actionable tasks.

Remember:
- Each task should start with "Task:"
- Each task should have all three components
- Be specific and clear
- Status must be exactly: completed, in-progress, or pending
- Consider your specific role and expertise when suggesting tasks
- Include relevant keywords in the description that match your expertise`;

        const response = await generateResponse(prompt);
        
        if (response) {
          const agentMessage: Message = {
            id: Date.now().toString(),
            agentId: agent.id,
            content: response,
            timestamp: new Date(),
            type: 'task'
          };
          setMessages(prev => [...prev, agentMessage]);
          addTasksFromResponse(response, agent.id);
        }
      }
    } catch (error) {
      console.error('Error processing message:', error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        agentId: 'system',
        content: 'An error occurred while processing your request. Please try again.',
        timestamp: new Date(),
        type: 'error'
      }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleTaskStatusChange = (taskId: string, newStatus: Task['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { ...task, status: newStatus, updatedAt: new Date() }
        : task
    ));
  };

  const handleTaskPriorityChange = (taskId: string, newPriority: Task['priority']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { ...task, priority: newPriority, updatedAt: new Date() }
        : task
    ));
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(task => task.id !== taskId));
    setExpandedTasks(prev => {
      const newSet = new Set(prev);
      newSet.delete(taskId);
      return newSet;
    });
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || task.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  return (
    <div className="min-h-screen grid grid-cols-2">
      {/* Left Section */}
      <div className="bg-gray-100 p-4 flex flex-col h-screen">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-indigo-600" />
            <h2 className="text-xl font-bold text-gray-900">AI Agents</h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500 flex items-center gap-1">
              <Zap className="w-4 h-4" />
              {agents.filter(a => a.isActive).length} Active
            </span>
          </div>
        </div>
        
        {/* Agents section - even more compact */}
        <div className="grid grid-cols-1 gap-2 mb-3 max-h-[25vh] overflow-y-auto pr-2">
          {agents.map(agent => (
            <AgentCard
              key={agent.id}
              agent={agent}
              onActivate={handleAgentActivation}
            />
          ))}
        </div>

        {/* Chat section - larger with better spacing */}
        <div className="flex-1 bg-white rounded-lg border overflow-hidden shadow-sm min-h-[65vh]">
          <AgentChat
            messages={messages}
            onSendMessage={handleSendMessage}
          />
        </div>
      </div>

      {/* Right Section */}
      <div className="bg-white p-8 overflow-y-auto">
        <div className="max-w-3xl mx-auto">
          <div className="sticky top-0 bg-white z-10 pb-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Tasks</h2>
                <p className="text-sm text-gray-500 mt-1">
                  {filteredTasks.length} task{filteredTasks.length !== 1 ? 's' : ''} {statusFilter !== 'all' && `(${statusFilter})`}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-lg">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-1.5 rounded ${viewMode === 'grid' ? 'bg-white shadow-sm' : 'hover:bg-white/50'}`}
                  >
                    <LayoutGrid className="w-4 h-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-1.5 rounded ${viewMode === 'list' ? 'bg-white shadow-sm' : 'hover:bg-white/50'}`}
                  >
                    <List className="w-4 h-4 text-gray-600" />
                  </button>
                </div>
                <button 
                  onClick={() => handleSendMessage('Please suggest new tasks that would be relevant for this project.')}
                  className="flex items-center gap-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!agents.some(a => a.isActive) || isProcessing}
                >
                  <Plus className="w-4 h-4" />
                  Add Task
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search tasks, descriptions, or tags..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
              
              <button
                className="p-2 border rounded-lg hover:bg-gray-50 transition-colors"
                onClick={() => {
                  setStatusFilter('all');
                  setPriorityFilter('all');
                  setSearchQuery('');
                }}
              >
                <SlidersHorizontal className="w-5 h-5 text-gray-600" />
              </button>
              
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as Task['status'] | 'all')}
                className="px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
              
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value as Task['priority'] | 'all')}
                className="px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Priority</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
          </div>

          <div className={viewMode === 'grid' ? 'grid grid-cols-2 gap-4' : 'space-y-4'}>
            {filteredTasks.length === 0 ? (
              <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed col-span-2">
                <div className="flex justify-center mb-4">
                  <AlertCircle className="w-12 h-12 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks found</h3>
                <p className="text-gray-500">
                  {agents.some(a => a.isActive)
                    ? searchQuery 
                      ? 'Try adjusting your search or filters'
                      : 'Start by asking the AI agents to suggest some tasks'
                    : 'Activate some agents to start creating tasks'}
                </p>
              </div>
            ) : (
              filteredTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  isExpanded={expandedTasks.has(task.id)}
                  onToggle={() => {
                    const newExpanded = new Set(expandedTasks);
                    if (newExpanded.has(task.id)) {
                      newExpanded.delete(task.id);
                    } else {
                      newExpanded.add(task.id);
                    }
                    setExpandedTasks(newExpanded);
                  }}
                  onStatusChange={(status) => handleTaskStatusChange(task.id, status)}
                  onPriorityChange={(priority) => handleTaskPriorityChange(task.id, priority)}
                  onDelete={handleDeleteTask}
                />
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;