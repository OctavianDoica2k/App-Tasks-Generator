// Helper to parse tasks from agent responses
export function parseTasksFromResponse(response: string): Array<{
  title: string;
  description: string;
  status: 'completed' | 'in-progress' | 'pending';
  tags: string[];
}> {
  try {
    // Split response into sections based on Task: marker
    const tasks: Array<{
      title: string;
      description: string;
      status: 'completed' | 'in-progress' | 'pending';
      tags: string[];
    }> = [];

    // Use regex to find all task blocks in the response
    const taskBlocks = response.match(/Task:[\s\S]*?(?=Task:|$)/g);

    if (!taskBlocks) return [];

    taskBlocks.forEach(block => {
      const titleMatch = block.match(/Task:\s*([^\n]+)/i);
      const descriptionMatch = block.match(/Description:\s*([^\n]+(?:\n(?!\w+:)[^\n]+)*)/i);
      const statusMatch = block.match(/Status:\s*(completed|in-progress|pending)/i);

      // Extract keywords/tags from the description
      const description = descriptionMatch?.[1]?.trim() || 'No description provided';
      const keywords = description
        .toLowerCase()
        .match(/\b(api|frontend|backend|design|ui|ux|database|testing|documentation|research|planning|implementation)\b/g) || [];
      const tags = Array.from(new Set(keywords)).map(k => k.charAt(0).toUpperCase() + k.slice(1));

      if (titleMatch?.[1]) {
        tasks.push({
          title: titleMatch[1].trim(),
          description: description,
          status: (statusMatch?.[1]?.toLowerCase() as 'completed' | 'in-progress' | 'pending') || 'pending',
          tags: tags
        });
      }
    });

    return tasks;
  } catch (error) {
    console.error('Error parsing tasks:', error);
    return [];
  }
}