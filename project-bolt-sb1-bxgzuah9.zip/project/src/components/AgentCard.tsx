import React, { useState } from 'react';
import { Agent } from '../types';
import { Bot, Clock, Tag, Activity, Award, Zap, Brain, Cpu, Info } from 'lucide-react';

interface AgentCardProps {
  agent: Agent;
  onActivate: (agentId: string) => void;
}

export function AgentCard({ agent, onActivate }: AgentCardProps) {
  const [showTooltip, setShowTooltip] = useState(false);

  const getAgentIcon = () => {
    switch (agent.role.toLowerCase()) {
      case 'task coordinator':
        return <Brain className="w-5 h-5" />;
      case 'technical implementation':
        return <Cpu className="w-5 h-5" />;
      default:
        return <Bot className="w-5 h-5" />;
    }
  };

  return (
    <div 
      className={`p-3 rounded-lg border ${
        agent.isActive 
          ? 'border-indigo-200 bg-gradient-to-br from-white to-indigo-50/30' 
          : 'border-gray-200 hover:border-indigo-200 hover:bg-white'
      } cursor-pointer transition-all group relative`}
      onClick={() => onActivate(agent.id)}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-lg ${
          agent.isActive ? 'bg-indigo-100' : 'bg-gray-100'
        } flex items-center justify-center transition-all relative group-hover:scale-105 transform duration-200`}>
          <div className={`transition-colors ${
            agent.isActive ? 'text-indigo-600' : 'text-gray-500'
          }`}>
            {getAgentIcon()}
          </div>
          {agent.isActive && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-green-500 rounded-full ring-2 ring-white" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-gray-900 text-sm truncate">{agent.name}</h3>
              <button
                className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowTooltip(!showTooltip);
                }}
              >
                <Info className="w-3 h-3 text-gray-400" />
              </button>
            </div>
            {agent.isActive && (
              <span className="flex items-center gap-1 text-xs font-medium text-green-600 bg-green-50 px-1.5 py-0.5 rounded-full">
                <Zap className="w-3 h-3" />
                Active
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 mb-1.5">
            <p className="text-xs font-medium text-gray-600">{agent.role}</p>
            <Activity className={`w-3 h-3 ${agent.isActive ? 'text-green-500' : 'text-gray-400'}`} />
          </div>

          <div className="flex flex-wrap gap-1 mb-2">
            {agent.expertise.slice(0, 3).map((skill, index) => (
              <span 
                key={index}
                className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-medium ${
                  agent.isActive 
                    ? 'bg-indigo-50 text-indigo-600' 
                    : 'bg-gray-100 text-gray-600'
                } transition-colors`}
              >
                <Tag className="w-2 h-2 mr-1" />
                {skill}
              </span>
            ))}
            {agent.expertise.length > 3 && (
              <span className="text-[10px] text-gray-500 px-1">+{agent.expertise.length - 3}</span>
            )}
          </div>
          
          {agent.lastActive && (
            <div className="flex items-center text-[10px] text-gray-400">
              <Clock className="w-2 h-2 mr-1" />
              {new Date(agent.lastActive).toLocaleTimeString()}
            </div>
          )}
        </div>
      </div>

      {/* Tooltip */}
      {showTooltip && (
        <div className="absolute left-0 right-0 top-full mt-2 z-10">
          <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-3 text-sm">
            <div className="mb-2">
              <h4 className="font-medium text-gray-900 mb-1">About {agent.name}</h4>
              <p className="text-gray-600 text-xs">{agent.description}</p>
            </div>
            <div className="space-y-1">
              <h5 className="text-xs font-medium text-gray-700">Expertise:</h5>
              <div className="flex flex-wrap gap-1">
                {agent.expertise.map((skill, index) => (
                  <span 
                    key={index}
                    className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-600"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}