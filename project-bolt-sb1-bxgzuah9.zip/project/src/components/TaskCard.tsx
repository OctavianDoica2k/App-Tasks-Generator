import React from 'react';
import { Task } from '../types';
import { ChevronDown, ChevronRight, ExternalLink, Clock, Tag, Trash2, Edit2, AlertCircle } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  isExpanded: boolean;
  onToggle: () => void;
  onStatusChange: (status: Task['status']) => void;
  onPriorityChange: (priority: Task['priority']) => void;
  onDelete?: (taskId: string) => void;
}

export function TaskCard({ task, isExpanded, onToggle, onStatusChange, onPriorityChange, onDelete }: TaskCardProps) {
  const getStatusColor = (status: Task['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 hover:bg-green-200 border-green-200';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200 border-yellow-200';
      case 'pending':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-200 border-blue-200';
    }
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'low':
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: Task['status']) => {
    const className = "w-3 h-3 mr-1";
    switch (status) {
      case 'completed':
        return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 6L9 17l-5-5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>;
      case 'in-progress':
        return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83" strokeWidth="2" strokeLinecap="round"/></svg>;
      case 'pending':
        return <AlertCircle className={className} />;
    }
  };

  return (
    <div 
      className={`border rounded-lg overflow-hidden transition-all ${
        isExpanded ? 'shadow-md' : 'hover:shadow-sm'
      } ${task.status === 'completed' ? 'opacity-75' : ''}`}
    >
      <div 
        className="p-4 cursor-pointer bg-white"
        onClick={onToggle}
      >
        <div className="flex items-start gap-4">
          <button 
            className="mt-1 text-gray-400 hover:text-gray-600 transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              onToggle();
            }}
          >
            {isExpanded ? (
              <ChevronDown className="w-5 h-5" />
            ) : (
              <ChevronRight className="w-5 h-5" />
            )}
          </button>
          
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <h3 className={`font-medium ${
                  task.status === 'completed' ? 'line-through text-gray-500' : 'text-gray-900'
                }`}>{task.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  className={`px-2.5 py-0.5 rounded-full text-xs font-medium transition-colors border flex items-center ${getStatusColor(task.status)}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    const statuses: Task['status'][] = ['pending', 'in-progress', 'completed'];
                    const currentIndex = statuses.indexOf(task.status);
                    const nextStatus = statuses[(currentIndex + 1) % statuses.length];
                    onStatusChange(nextStatus);
                  }}
                >
                  {getStatusIcon(task.status)}
                  {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                </button>
                <button 
                  className={`px-2.5 py-0.5 rounded-full text-xs font-medium border flex items-center gap-1 ${getPriorityColor(task.priority)}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    const priorities: Task['priority'][] = ['low', 'medium', 'high'];
                    const currentIndex = priorities.indexOf(task.priority);
                    const nextPriority = priorities[(currentIndex + 1) % priorities.length];
                    onPriorityChange(nextPriority);
                  }}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    task.priority === 'high' ? 'bg-red-500' :
                    task.priority === 'medium' ? 'bg-orange-500' :
                    'bg-gray-500'
                  }`} />
                  {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                </button>
              </div>
            </div>

            {task.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mb-2">
                {task.tags.map((tag, index) => (
                  <span 
                    key={index}
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-50 text-indigo-600 border border-indigo-100"
                  >
                    <Tag className="w-3 h-3 mr-1" />
                    {tag}
                  </span>
                ))}
              </div>
            )}

            <div className="flex items-center text-xs text-gray-400 gap-4">
              <span className="flex items-center">
                <Clock className="w-3 h-3 mr-1" />
                Created {new Date(task.createdAt).toLocaleDateString()}
              </span>
              {task.assignedTo && (
                <span className="flex items-center gap-1">
                  <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <circle cx="12" cy="7" r="4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  {task.assignedTo}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {isExpanded && (
        <div className="px-12 py-4 text-gray-600 border-t bg-gray-50">
          <p className="mb-4 whitespace-pre-wrap">{task.description}</p>
          <div className="flex justify-end gap-2">
            <button 
              className="px-3 py-1.5 text-sm text-gray-600 bg-white border rounded-md hover:bg-gray-50 transition-colors flex items-center gap-1 shadow-sm"
              onClick={() => {/* TODO: Implement edit */}}
            >
              <Edit2 className="w-3 h-3" /> Edit
            </button>
            {onDelete && (
              <button 
                className="px-3 py-1.5 text-sm text-red-600 bg-white border border-red-200 rounded-md hover:bg-red-50 transition-colors flex items-center gap-1 shadow-sm"
                onClick={() => onDelete(task.id)}
              >
                <Trash2 className="w-3 h-3" /> Delete
              </button>
            )}
            {task.hasExternalLink && (
              <button className="px-3 py-1.5 text-sm text-white bg-indigo-600 rounded-md hover:bg-indigo-700 transition-colors flex items-center gap-1 shadow-sm">
                View <ExternalLink className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}