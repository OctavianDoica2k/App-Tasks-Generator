import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';
import { Send, Bot, User, AlertTriangle } from 'lucide-react';

interface AgentChatProps {
  messages: Message[];
  onSendMessage: (content: string) => void;
}

export function AgentChat({ messages, onSendMessage }: AgentChatProps) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isTyping, setIsTyping] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      setIsTyping(true);
      await onSendMessage(input);
      setInput('');
      setIsTyping(false);
      inputRef.current?.focus();
    }
  };

  const getMessageStyle = (message: Message) => {
    if (message.type === 'error') {
      return 'bg-red-50 border-red-200 text-red-700';
    }
    return message.agentId === 'user'
      ? 'bg-indigo-600 text-white'
      : 'bg-white border shadow-sm';
  };

  return (
    <div className="flex flex-col h-full">
      <div className="bg-white border-b px-4 py-2.5 flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold text-gray-900">Chat</h3>
          <p className="text-xs text-gray-500">Ask agents to suggest and manage tasks</p>
        </div>
        {isTyping && (
          <span className="text-xs text-gray-500 animate-pulse">
            Agents are thinking...
          </span>
        )}
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 ? (
          <div className="text-center py-8">
            <Bot className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No messages yet. Start a conversation!</p>
          </div>
        ) : (
          messages.map((message) => (
            <div 
              key={message.id} 
              className={`flex gap-3 ${message.agentId === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`flex gap-3 max-w-[85%] ${
                  message.agentId === 'user' ? 'flex-row-reverse' : 'flex-row'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.type === 'error' ? 'bg-red-100' :
                  message.agentId === 'user' ? 'bg-indigo-100' : 'bg-gray-100'
                }`}>
                  {message.type === 'error' ? (
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                  ) : message.agentId === 'user' ? (
                    <User className="w-4 h-4 text-indigo-600" />
                  ) : (
                    <Bot className="w-4 h-4 text-gray-600" />
                  )}
                </div>
                <div className={`rounded-lg p-3 ${getMessageStyle(message)}`}>
                  <div className="text-xs mb-1 font-medium">
                    {message.type === 'error' ? 'System' :
                     message.agentId === 'user' ? 'You' : `Agent ${message.agentId}`}
                  </div>
                  <div className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</div>
                  <div className="text-[10px] mt-1.5 opacity-70">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
        {isTyping && (
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="p-3 border-t bg-white">
        <div className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-gray-50 hover:bg-white focus:bg-white transition-colors text-sm"
            disabled={isTyping}
          />
          <button
            type="submit"
            disabled={isTyping || !input.trim()}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline text-sm">Send</span>
          </button>
        </div>
      </form>
    </div>
  );
}